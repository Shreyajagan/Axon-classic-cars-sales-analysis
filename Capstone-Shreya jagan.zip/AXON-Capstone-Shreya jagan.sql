---1) to find total number of customers
select distinct count(customernumber) from customers;

---2) to find the total number of products
select distinct count(productcode) from products;

---3) to find the total number of orders placed
select distinct count(ordernumber) from orders;

---4) to find top 5 selling products
select p.productcode,productname, sum(quantityordered*priceeach) as totalsales
from products p join orderdetails od 
on p.productcode=od.productcode
group by p.productcode,productname
order by totalsales desc
limit 5;


---5) to find the highest number of customers from which country
select country, count(*) as total_customers
from customers
group by country
order by total_customers desc
limit 1;


---6) to find the total profit
select sum(od.quantityordered * (od.priceeach - p.buyprice)) as totalprofit
from orderdetails od
join products p on od.productcode = p.productcode
join orders o on od.ordernumber = o.ordernumber
join customers c on o.customernumber = c.customernumber;


---7) to find who is reporting to whom
create VIEW employee_hierarchy as
select emp.firstname as employeename,rep.firstname as reports_to
from employees emp
left join employees rep
on emp.reportsto=rep.employeenumber;


---8) to list the customers who does not belong to any state
select customernumber,customername,city,country
from customers
where state is null;


---9) to find sales representative for each customer
select customernumber,customername,concat(firstname," ",lastname) as  sales_representative
from customers c join employees e 
on c.salesrepemployeenumber = e.employeenumber
where salesrepemployeenumber is not null;


---10) to return the employeenumber who are reported to and the number of employees that report to them.
select reportsto as employee_id,  count(*) as no_of_employees_reporting
from employees
where reportsto is not null
group by reportsto
order by no_of_employees_reporting desc;


---11) to find the employee name and their office address
select o.officecode,employeenumber,concat(firstname," ",lastname) as employeename,
concat(addressline1,",",addressline2) as address,city,state,country,postalcode
from employees e join offices o
on e.officecode=o.officecode;


---12) to retrieve the list whose product lines have buses or cycles
select * from products where productline like "%buses%" or productline like "%cycles%" ;


---13)  to find highest amount paid on which order and the customer details
select o.ordernumber,c.customernumber,customername,sum(quantityordered*priceeach) as total_amount
from orderdetails od join orders o on o.ordernumber=od.ordernumber
join customers c on c.customernumber=o.customernumber
group by ordernumber
order by total_amount desc
limit 1;


---14) to find number of customers for each sales representative
select employeenumber,concat(firstname," ",lastname) as fullname,count(*) as total_customers
from customers c join employees e 
on c.salesrepemployeenumber = e.employeenumber
where salesrepemployeenumber is not null
group by employeenumber
order by total_customers desc;


---15) to find number of orders placed by each customer
select customernumber,count(ordernumber) as total_orders
from orders
group by customernumber
order by count(ordernumber);


---16) to find customer who ordered highest number of products
select o.customernumber,customername,count(productcode) as total_products
from orderdetails od join orders o
on od.ordernumber=o.ordernumber
join customers c on c.customernumber=o.customernumber
group by customernumber
order by total_products desc limit 1;


---17) to find the difference in order date and shipment date
select customername,datediff(shippeddate,orderdate) as total_days
from customers c join orders o
on c.customernumber=o.customernumber
where shippeddate is not null
order by total_days desc;


---18) to find total amount paid by each customer
select p.customernumber,customername,sum(amount) total_amount
from payments p join customers c 
on p.customernumber = c.customernumber
group by customernumber
order by sum(amount) desc;


---19) the customers who buyed the highest number of products
select customername,concat(contactfirstname," ",contactlastname) as contact_name,count(p.productcode) as total_products
from customers c join orders o
on c.customernumber=o.customernumber
join orderdetails od on o.ordernumber=od.ordernumber
join products p on od.productcode=p.productcode
group by customername,contact_name
order by total_products desc
limit 1;


---20) to find total number of products for each productline
select productline,count(productcode) as total_products
from products 
group by productline
order by total_products desc;


---21)to find total number of orders for each product.
select p.productcode,productname,sum(quantityordered) as total_quantity_ordered
from products p join orderdetails od
on p.productcode=od.productcode
group by p.productcode,productname
order by total_quantity_ordered desc;


---22)to find the customers who ordered the products from all the productlines
select c.customernumber,customername,count(distinct pl.productline) as number_of_productlines
from customers c
join orders o on c.customernumber=o.customernumber
join orderdetails od on o.ordernumber=od.ordernumber
join products pr on pr.productcode=od.productcode
join productlines pl on pl.productline=pr.productline
group by c.customernumber,customername
having number_of_productlines=7;

---23) to find the total number of employees
select Count(employeenumber) as Total_employees from employees;

---24) to find distinct jobtitles
select distinct jobtitle from employees;


---25) to find the orders which contains more than 10 products
select ordernumber,count(productcode) as total_products 
from orderdetails
group by ordernumber
having count(productcode)>10
order by total_products desc;


---26) to find the customers and their country who dont have sales representative
select customernumber,customername,country,city
from customers
where salesrepemployeenumber is null;


---27) to find the orders placed on monday
select dayname(orderdate) day,count(ordernumber) as total_orders
from orders
where dayname(orderdate)="monday"
group by dayname(orderdate);


---28) to find product wise total sales
select p.productcode,productname,sum(quantityordered*priceeach) as total_sales
from products p join orderdetails od 
on p.productcode=od.productcode
group by p.productcode,productname
order by total_sales desc;


---29) to find the payment details of the customer named jean king
create VIEW customer_payment_details as
select c.customername, concat( contactfirstname," ", contactlastname) as contactname, p.paymentdate, p.amount
from customers c
join payments p on c.customernumber = p.customernumber;

select * from customer_payment_details where contactname= "jean king";


---30) to calculate the total sales and profit by office:

create VIEW sales_and_profit_by_office as
select ofi.officecode, ofi.city, ofi.country, sum(od.quantityordered * od.priceeach) as sales, 
sum(od.quantityordered * (od.priceeach - p.buyprice)) as totalprofit
from orderdetails od
join products p on od.productcode = p.productcode
join orders o on od.ordernumber = o.ordernumber
join customers c on o.customernumber = c.customernumber
join employees e on c.salesrepemployeenumber=e.employeenumber
join offices ofi on e.officecode=ofi.officecode
group by ofi.officecode, ofi.city, ofi.country order by totalprofit desc;


select * from sales_and_profit_by_office where city="nyc";


---31) to calculate average sales

select avg(sales)
from (
    select sum(od.quantityordered * od.priceeach) as sales
    from orderdetails od
    group by od.ordernumber
) as average_sales;


---32) to find how many orders have placed by customers in december,2004.
select year(orderdate) year,month(orderdate) month,count(*) total_orders
from orders
where year(orderdate)=2004 and month(orderdate)=12
group by year(orderdate),month(orderdate);


---33) to find the  the customers whose total sales exceed 5000.
select c.customernumber, c.customername, sum(od.quantityordered * od.priceeach) as totalsales
from customers c
join orders o on c.customernumber = o.customernumber
join orderdetails od on o.ordernumber = od.ordernumber
group by c.customernumber, c.customername
having totalsales> 5000;


---34) months with above average total sales
WITH monthlysales as (
    select year(o.orderdate) as orderyear, month(o.orderdate) as ordermonth,
    sum(od.quantityordered * od.priceeach) as totalsales
    from orders o
    join orderdetails od on o.ordernumber = od.ordernumber
    group by year(o.orderdate), month(o.orderdate)
)
select orderyear, ordermonth, totalsales
from monthlysales
where totalsales > (
    select avg(totalsales)
    from monthlysales
);






